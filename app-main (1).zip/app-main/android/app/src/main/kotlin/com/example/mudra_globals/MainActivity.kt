package com.example.mudra_globals

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
